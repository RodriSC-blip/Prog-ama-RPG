#include "Mago.h"
#include <iostream>

Mago::Mago() : Combatente() { nome = "Mago Padr�o"; }

Mago::Mago(std::string nome, int hp, int atk, int def, int vel) 
    : Combatente(nome, hp, atk, def, vel) {}

void Mago::atacar(Combatente& alvo) {
    std::cout << "[BOLA DE FOGO] ";
    Combatente::atacar(alvo);
}

void Mago::exibirStatus() const {
    std::cout << "[MAGO] ";
    Combatente::exibirStatus();
}

#ifndef ARQUEIRO_H
#define ARQUEIRO_H

#include "Combatente.h"

class Arqueiro : public Combatente {
public:
    Arqueiro();
    Arqueiro(std::string nome, int hp, int atk, int def, int vel);
    void atacar(Combatente& alvo) override;
    void exibirStatus() const override;
};

#endif

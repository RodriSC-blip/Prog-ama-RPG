#ifndef MAGO_H
#define MAGO_H

#include "Combatente.h"

class Mago : public Combatente {
public:
    Mago();
    Mago(std::string nome, int hp, int atk, int def, int vel);
    void atacar(Combatente& alvo) override;
    void exibirStatus() const override;
};

#endif

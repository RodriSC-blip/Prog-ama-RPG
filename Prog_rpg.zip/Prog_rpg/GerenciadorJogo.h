#ifndef GERENCIADORJOGO_H
#define GERENCIADORJOGO_H

#include "Combatente.h"
#include <vector>

class GerenciadorJogo {
private:
    std::vector<Combatente*> herois;
    int ondasVencidas;
    const int ALVO_VITORIA = 5;

    friend class Auditoria;

public:
    GerenciadorJogo();
    ~GerenciadorJogo();

    void adicionarHeroi(Combatente* h);
    void iniciarJogo();
};

#endif

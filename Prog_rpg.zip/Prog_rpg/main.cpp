#include "GerenciadorJogo.h"
#include <iostream>

int main() {
    GerenciadorJogo jogo;
    jogo.iniciarJogo();
    return 0;
}
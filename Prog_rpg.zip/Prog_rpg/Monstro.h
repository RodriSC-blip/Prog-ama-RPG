#ifndef MONSTRO_H
#define MONSTRO_H

#include "Combatente.h"

class Monstro : public Combatente {
public:
    Monstro(std::string nome, int hp, int atk, int def, int vel);
    void exibirStatus() const override;
};

#endif

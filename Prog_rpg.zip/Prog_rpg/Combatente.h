#ifndef COMBATENTE_H
#define COMBATENTE_H

#include <string>

class Combatente {
protected:
    std::string nome;
    int hp;
    int ataque;
    int defesa;
    int velocidade;

public:
    // Construtor padrão
    Combatente();
    
    // Construtor parametrizado
    Combatente(std::string nome, int hp, int ataque, int defesa, int velocidade);
    
    virtual ~Combatente(); // Destrutor virtual obrigatório

    // Getters (const)
    std::string getNome() const;
    int getHp() const;
    int getAtaque() const;
    int getDefesa() const;
    int getVelocidade() const;

    // Setters com validação
    void setHp(int novoHp);

    // Métodos de combate (polimórficos)
    virtual void atacar(Combatente& alvo);
    virtual void receberDano(int dano);
    virtual void exibirStatus() const;

    bool estaVivo() const;
};

#endif
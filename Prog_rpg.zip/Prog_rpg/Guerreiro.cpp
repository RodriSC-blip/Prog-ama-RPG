#include "Guerreiro.h"
#include <iostream>

Guerreiro::Guerreiro() : Combatente() {
    nome = "Guerreiro Padr�o";
}

Guerreiro::Guerreiro(std::string nome, int hp, int atk, int def, int vel) 
    : Combatente(nome, hp, atk, def, vel) {}

void Guerreiro::atacar(Combatente& alvo) {
    std::cout << "[GOLPE PESADO] ";
    Combatente::atacar(alvo);
}

void Guerreiro::exibirStatus() const {
    std::cout << "[GUERREIRO] ";
    Combatente::exibirStatus();
}

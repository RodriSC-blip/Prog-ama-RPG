#ifndef GUERREIRO_H
#define GUERREIRO_H

#include "Combatente.h"

class Guerreiro : public Combatente {
public:
    Guerreiro();
    Guerreiro(std::string nome, int hp, int atk, int def, int vel);
    void atacar(Combatente& alvo) override;
    void exibirStatus() const override;
};

#endif

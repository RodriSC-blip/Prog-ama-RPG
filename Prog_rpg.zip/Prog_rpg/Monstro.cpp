#include "Monstro.h"
#include <iostream>

Monstro::Monstro(std::string nome, int hp, int atk, int def, int vel) 
    : Combatente(nome, hp, atk, def, vel) {}

void Monstro::exibirStatus() const {
    std::cout << "[MONSTRO] ";
    Combatente::exibirStatus();
}

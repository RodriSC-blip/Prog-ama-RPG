#include "Arqueiro.h"
#include <iostream>

Arqueiro::Arqueiro() : Combatente() { nome = "Arqueiro Padr�o"; }

Arqueiro::Arqueiro(std::string nome, int hp, int atk, int def, int vel) 
    : Combatente(nome, hp, atk, def, vel) {}

void Arqueiro::atacar(Combatente& alvo) {
    std::cout << "[TIRO PRECISO] ";
    Combatente::atacar(alvo);
}

void Arqueiro::exibirStatus() const {
    std::cout << "[ARQUEIRO] ";
    Combatente::exibirStatus();
}

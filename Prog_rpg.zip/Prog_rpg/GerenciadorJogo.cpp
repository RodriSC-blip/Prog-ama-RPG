#include "GerenciadorJogo.h"
#include "Guerreiro.h"
#include "Arqueiro.h"
#include "Mago.h"
#include "Monstro.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

class Auditoria {
public:
    static void exibirInfoPrivada(const Combatente* c) {
        std::cout << "Auditoria: " << c->getNome() << " - HP interno: " << c->getHp() << "\n";
    }
};

GerenciadorJogo::GerenciadorJogo() : ondasVencidas(0) {
    srand(time(0));
}

GerenciadorJogo::~GerenciadorJogo() {
    for (auto h : herois) delete h;
}

void GerenciadorJogo::adicionarHeroi(Combatente* h) {
    herois.push_back(h);
}

void GerenciadorJogo::iniciarJogo() {
    adicionarHeroi(new Guerreiro("Thorin, o Guerreiro", 120, 22, 12, 6));
    adicionarHeroi(new Arqueiro("Legolas, o Arqueiro", 85, 28, 6, 14));
    adicionarHeroi(new Mago("Gandalf, o Cinzento", 75, 35, 4, 9));

    while (!herois.empty() && ondasVencidas < ALVO_VITORIA) {
        std::cout << "\n=== ONDA " << ondasVencidas + 1 << " ===\n";

        int mHp = rand() % 60 + 50;
        int mAtk = rand() % 18 + 12;
        int mDef = rand() % 6 + 3;
        int mVel = rand() % 12 + 5;

        Monstro monstro("Monstro Emboscador", mHp, mAtk, mDef, mVel);
        monstro.exibirStatus();

        std::cout << "\nEscolha um her�i:\n";
        for (size_t i = 0; i < herois.size(); ++i) {
            std::cout << i << " - ";
            herois[i]->exibirStatus();
        }

        int escolha;
        std::cin >> escolha;

        if (escolha < 0 || escolha >= static_cast<int>(herois.size()) || !herois[escolha]->estaVivo()) {
            std::cout << "Escolha inv�lida!\n";
            continue;
        }

        Combatente* heroi = herois[escolha];

        while (heroi->estaVivo() && monstro.estaVivo()) {
            if (heroi->getVelocidade() >= monstro.getVelocidade()) {
                heroi->atacar(monstro);
                if (monstro.estaVivo()) monstro.atacar(*heroi);
            } else {
                monstro.atacar(*heroi);
                if (heroi->estaVivo()) heroi->atacar(monstro);
            }
        }

        if (!monstro.estaVivo()) {
            ondasVencidas++;
            std::cout << "Monstro derrotado!\n";
        }

        if (!heroi->estaVivo()) {
            std::cout << heroi->getNome() << " tombou em combate!\n";
            delete heroi;
            herois.erase(herois.begin() + escolha);
        }
    }

    if (herois.empty()) {
        std::cout << "\nGAME OVER! Sobreviveu a " << ondasVencidas << " ondas.\n";
    } else {
        std::cout << "\nVIT�RIA! Voc� completou todas as ondas!\n";
    }
}

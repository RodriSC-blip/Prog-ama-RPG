#include "Combatente.h"
#include <iostream>

Combatente::Combatente() 
    : nome("Desconhecido"), hp(50), ataque(10), defesa(5), velocidade(5) {}

Combatente::Combatente(std::string nome, int hp, int ataque, int defesa, int velocidade)
    : nome(nome), hp(hp), ataque(ataque), defesa(defesa), velocidade(velocidade) {
    if (this->hp < 0) this->hp = 0;
}

Combatente::~Combatente() {}

std::string Combatente::getNome() const { return nome; }
int Combatente::getHp() const { return hp; }
int Combatente::getAtaque() const { return ataque; }
int Combatente::getDefesa() const { return defesa; }
int Combatente::getVelocidade() const { return velocidade; }

void Combatente::setHp(int novoHp) {
    hp = (novoHp < 0) ? 0 : novoHp;
}

void Combatente::atacar(Combatente& alvo) {
    std::cout << nome << " ataca " << alvo.getNome() << "!\n";
    alvo.receberDano(ataque);
}

void Combatente::receberDano(int dano) {
    int danoReal = dano - defesa;
    if (danoReal < 0) danoReal = 0;
    setHp(hp - danoReal);
}

void Combatente::exibirStatus() const {
    std::cout << nome 
              << " | HP: " << hp
              << " | ATK: " << ataque
              << " | DEF: " << defesa
              << " | VEL: " << velocidade << "\n";
}

bool Combatente::estaVivo() const {
    return hp > 0;
}